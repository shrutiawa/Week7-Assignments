import { useEffect, useState } from "react";
import {useNavigate } from 'react-router-dom';
import axios from "axios";
import EditUser from "./edit-user.component";

let Home = () => {
    const navigate = useNavigate();
    let [user, setUser] = useState({ firstname: "", lastname: "", email: "" })
    let [users, setUsers] = useState([]);

    let reload = () => {
        axios.get("http://localhost:5050/data")
            .then(res => setUsers(res.data))
            .catch(err => console.log("Error ", err))
    }

    useEffect(() => {
        reload();
    }, []);

    const edithandleButtonClick = () => {
      navigate('/edit-user');
    };
    const homehandleButtonClick = () => {
      navigate('/');
    };
    const addhandleButtonClick = () => {
      navigate('/add-user');
    };
    return <div className="container">
            <h1>User's Detail</h1>
            
        <table className="table">
            <thead>
                <tr>
                    <th scope="col">SL #</th>
                    <th scope="col">First</th>
                    <th scope="col">Last</th>
                    <th scope="col">eMail</th>
                </tr>
            </thead>
            <tbody>
                {
                    users.map(({ firstname, lastname, email, _id }, idx) => <tr key={_id}>
                        <th scope="row">{idx}</th>
                        <td>{firstname}</td>
                        <td>{lastname}</td>
                        <td>{email}</td>
                    </tr>
                    )
                }
            </tbody>
        </table>
<br/>
        <button className="btn btn-primary" onClick={homehandleButtonClick}>Home</button>&nbsp;
            <button className="btn btn-primary" onClick={addhandleButtonClick}>Add User</button> &nbsp;
            <button className="btn btn-primary" onClick={edithandleButtonClick}>Edit User</button>&nbsp;
    </div>
}
export default Home