import axios from "axios";
import { useEffect, useState } from "react";
import {useNavigate } from 'react-router-dom';

let AddUser =()=>{
    const navigate = useNavigate();
    let[user, setUser] = useState({firstname: "", lastname : "", email : ""})
    let[users, setUsers] = useState([]);
    let [show,setShow]=useState(false)
    let reload = () => {
        axios.get("http://localhost:5050/data")
        .then(res => setUsers(res.data) )
        .catch(err => console.log("Error ", err))
    }
    useEffect(()=>{
        reload();
    },[]);
    let userDetailsChangeHandler = (evt) => {
        setUser({...user, [evt.target.id] : evt.target.value }) ;
    }
    let addNewUser = () =>{
        if(user.firstname && user.lastname && user.email){
            axios.post("http://localhost:5050/data", user)
            .then( res => {
                console.log(res.data.message);
                reload();
                setShow(true)
                setUser({firstname: "", lastname : "", email : ""});
            })
            .catch(err => console.log("Error ", err ))
        }else{
            alert("add all info before submitting the form")
        }
    }
    const homehandleButtonClick = () => {
        navigate('/');
      };
    return <div className="container">
        <h2>Add A New User</h2>
        <div className="mb-3">
            <label htmlFor="firstname" className="form-label">First Name</label>
            <input onChange={ userDetailsChangeHandler } value={ user.firstname } type="text" className="form-control" id="firstname" placeholder="First Name"/>
        </div>
        <div className="mb-3">
            <label htmlFor="lastname" className="form-label">Last Name</label>
            <input onChange={userDetailsChangeHandler } value={ user.lastname } type="text" className="form-control" id="lastname" placeholder="Last Name"/>
        </div>
        <div className="mb-3">
            <label htmlFor="email" className="form-label">eMail</label>
            <input onChange={userDetailsChangeHandler } value={ user.email } type="email" className="form-control" id="email" placeholder="eMail id"/>
        </div>
        <div className="mb-3">
         <button onClick={addNewUser} className="btn btn-primary">Register</button> &nbsp;
         <button className="btn btn-primary" onClick={homehandleButtonClick}>Home</button>
         {show && <table className="table">
                <thead>
                    <tr>
                        <th scope="col">SL #</th>
                        <th scope="col">First</th>
                        <th scope="col">Last</th>
                        <th scope="col">eMail</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        users.map(({firstname, lastname, email, _id }, idx) => <tr key={_id}>
                                        <th scope="row">{idx}</th>
                                        <td>{firstname}</td>
                                        <td>{lastname}</td>
                                        <td>{email}</td>
                                    </tr>
                    )
                    }                    
                </tbody>
            </table>}
        </div>
    </div>
}
export default AddUser