import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

let EditUser = () => {
    const navigate = useNavigate();
    let [euser, setEUser] = useState({ firstname: "", lastname: "", email: "", _id: "" })
    let [users, setUsers] = useState([]);
    let [show,setShow]=useState(false)
    let reload = () => {
        axios.get("http://localhost:5050/data")
            .then(res => setUsers(res.data))
            .catch(err => console.log("Error ", err))
    }
    useEffect(() => {
        reload();
    }, []);
    let editClickHandler = (hid) => {
        console.log(hid)
        axios.get("http://localhost:5050/edit/"+hid)
        .then(res => {
         setEUser(res.data);
        })
        .catch()
     }
    let editUser=()=>{
        setShow(true)
    }
    let userDetailsUpdateHandler = (evt) => {
        setEUser({ ...euser, [evt.target.id]: evt.target.value });
    }
    let updateUserInfo = () => {
        if (euser.firstname && euser.lastname && euser.email) {
            axios.post("http://localhost:5050/edit/" + euser._id, euser)
                .then(res => {
                    console.log(res.data.message);
                    reload();
                    setEUser({ firstname: "", lastname: "", email: "", _id: "" });
                })
                .catch(err => console.log("Error ", err))
        } else {
            alert("add all info before submitting the form")
        }
    }
    let deleteClickHandler = (hid) => {
        axios.delete("http://localhost:5050/delete/"+hid)
        .then(res => {
            console.log(res.data);
            alert(res.data.message)
            reload();
        })
        .catch(err => console.log("Error ", err))
    }
    const homehandleButtonClick = () => {
        navigate('/');
      };
        return <div className="container">
            <h2>Edit User Info</h2>
            
            <div className="mb-3">
                <label htmlFor="firstname" className="form-label">First Name</label>
                <input onChange={userDetailsUpdateHandler} value={euser.firstname} type="text" className="form-control" id="firstname" placeholder="First Name" />
            </div>
            <div className="mb-3">
                <label htmlFor="lastname" className="form-label">Last Name</label>
                <input onChange={userDetailsUpdateHandler} value={euser.lastname} type="text" className="form-control" id="lastname" placeholder="Last Name" />
            </div>
            <div className="mb-3">
                <label htmlFor="email" className="form-label">eMail</label>
                <input onChange={userDetailsUpdateHandler} value={euser.email} type="email" className="form-control" id="email" placeholder="eMail id" />
                <input value={euser._id} type="hidden" />
            </div>
            <div className="mb-3">
                {!show && <button onClick={editUser} className="btn btn-warning">Edit</button>}&nbsp;
                <button onClick={updateUserInfo} className="btn btn-primary">Update</button>&nbsp;
                <button className="btn btn-primary" onClick={homehandleButtonClick}>Home</button>
                {show && <table className="table">
                <thead>
                    <tr>
                        <th scope="col">SL #</th>
                        <th scope="col">First</th>
                        <th scope="col">Last</th>
                        <th scope="col">eMail</th>
                        <th scope="col">Edit</th>
                        <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        users.map(({firstname, lastname, email, _id }, idx) => <tr key={_id}>
                                        <th scope="row">{idx}</th>
                                        <td>{firstname}</td>
                                        <td>{lastname}</td>
                                        <td>{email}</td>
                                        <td><button onClick={ () => editClickHandler(_id) } className="btn btn-warning">Edit</button></td>
                                        <td><button onClick={ () => deleteClickHandler(_id) } className="btn btn-danger">Delete</button></td>
                                    </tr>
                    )
                    }                    
                </tbody>
            </table>}
            
            </div>
        </div>
    }
    export default EditUser