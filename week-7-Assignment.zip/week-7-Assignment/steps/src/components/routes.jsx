import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, BrowserRouter } from 'react-router-dom';
import Home from './home';
import EditUser from './edit-user.component';
import AddUser from './add-user';


const App = () => {
    return <div className='container'>
        <div>
            <BrowserRouter>
                <Link to="/"></Link>
                <Link to="/add-user"></Link>
                <Link to="/edit-user"></Link>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/add-user" element={<AddUser />} />
                    <Route path="/edit-user" element={<EditUser />} />
                </Routes>
            </BrowserRouter>
        </div>
    </div>
};

export default App;