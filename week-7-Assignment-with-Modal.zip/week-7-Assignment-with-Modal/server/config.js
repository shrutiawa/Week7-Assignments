let config = {
    port : 5050,
    host : "localhost",
    dbuser : "admin",
    dbpass : "qOAPRakkQTXWfThe",
    dbname : "valtechDB",
    dbstring : "voa9j2x"
}
 
module.exports = config;