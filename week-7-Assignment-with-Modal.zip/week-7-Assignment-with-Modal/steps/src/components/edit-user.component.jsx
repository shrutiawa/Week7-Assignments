import axios from "axios";
import { useEffect, useState } from "react";

let EditUser = ({user,closeModal}) => {
    let [euser, setEUser] = useState({ firstname: "", lastname: "", email: "", _id: "" })
    let [show, setShow] = useState(false)
    useEffect(() => {
        axios.get("http://localhost:5050/edit/" + user._id)
            .then(res => {
                setEUser(res.data);
            })
            .catch()
    }, [user]);
    let userDetailsUpdateHandler = (evt) => {
        setEUser({ ...euser, [evt.target.id]: evt.target.value });
    }
    let updateUserInfo = () => {
        if (euser.firstname && euser.lastname && euser.email) {
            setShow(true)
            axios.post("http://localhost:5050/edit/" + euser._id, euser)
                .then(res => {
                    console.log(res.data.message);
                    setEUser({ firstname: "", lastname: "", email: "", _id: "" });
                })
                .catch(err => console.log("Error ", err))
        } else {
            alert("add all info before submitting the form")
        }
    }
    let deleteClickHandler = () => {
        axios.delete("http://localhost:5050/delete/" + user._id)
            .then(res => {
                console.log(res.data);
                alert(res.data.message)
                closeModal()
            })
            .catch(err => console.log("Error ", err))
    }
    let idx=0
    return <div className="container">
        <h2>Edit User Info</h2>
        <div className="mb-3">
            <label htmlFor="firstname" className="form-label">First Name</label>
            <input onChange={userDetailsUpdateHandler} value={euser.firstname} type="text" className="form-control" id="firstname" placeholder="First Name" />
        </div>
        <div className="mb-3">
            <label htmlFor="lastname" className="form-label">Last Name</label>
            <input onChange={userDetailsUpdateHandler} value={euser.lastname} type="text" className="form-control" id="lastname" placeholder="Last Name" />
        </div>
        <div className="mb-3">
            <label htmlFor="email" className="form-label">eMail</label>
            <input onChange={userDetailsUpdateHandler} value={euser.email} type="email" className="form-control" id="email" placeholder="eMail id" />
            <input value={euser._id} type="hidden" />
        </div>
        <button onClick={() => updateUserInfo(user)} className="btn btn-primary">Update</button>&nbsp;
        <button onClick={() => deleteClickHandler()} className="btn btn-danger">Delete</button>
        {show && <table className="table">
            <thead>
                <tr>
                    <th scope="col">SL #</th>
                    <th scope="col">First</th>
                    <th scope="col">Last</th>
                    <th scope="col">eMail</th>
                </tr>
            </thead>
            <tbody>
                {user && (
                    <tr key={user._id}>
                       <th>{idx}</th>
                        <td>{user.firstname}</td>
                        <td>{user.lastname}</td>
                        <td>{user.email}</td>
                    </tr>
                )}
            </tbody>
        </table>}
    </div>
}
export default EditUser