import React from 'react';
import {Routes, Route, Link, BrowserRouter } from 'react-router-dom';
import Home from './home';
import AddUser from './add-user';


const App = () => {
    return <div className='container'>
        <div>
            <BrowserRouter>
                <Link to="/"></Link>
                <Link to="/add-user"></Link>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/add-user" element={<AddUser />} />
                </Routes>
            </BrowserRouter>
        </div>
    </div>
};

export default App;